class AppUser {
 final String id,username; String name,bio; int avatarHue,followers,following; bool isVerified;
 AppUser({required this.id,required this.username,required this.name,this.bio='',this.avatarHue=210,this.followers=0,this.following=0,this.isVerified=false});
}
class VoicePost {
 final String id,userId; final DateTime createdAt; final Duration duration; final String? localPath; String caption; int likes; bool liked;
 VoicePost({required this.id,required this.userId,required this.createdAt,required this.duration,this.localPath,this.caption='',this.likes=0,this.liked=false});
}
class ChatMessage {
 final String senderId,localPath; final Duration duration; final DateTime createdAt;
 ChatMessage({required this.senderId,required this.localPath,required this.duration,required this.createdAt});
}
class Conversation {
 final String id,otherUserId; final List<ChatMessage> messages;
 Conversation(this.id,this.otherUserId,[List<ChatMessage>? messages]):messages=messages??[];
}
