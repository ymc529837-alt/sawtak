import 'dart:io';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../services/app_state.dart';
import '../services/audio_service.dart';
import '../widgets/common.dart';
import '../theme.dart';

class ChatScreen extends StatefulWidget {
  final String userId;
  const ChatScreen({super.key, required this.userId});
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  bool recording = false;
  String? path;
  DateTime? start;

  Future<void> begin() async {
    if (!await AudioService.instance.ensureMicPermission()) {
      if (mounted) showAppSnackBar(context, 'امنح إذن الميكروفون', isError: true);
      return;
    }
    try {
      path = await AudioService.instance.newRecordingPath();
      await AudioService.instance.startRecording(path!);
      if (mounted) setState(() { recording = true; start = DateTime.now(); });
    } catch (e) {
      if (mounted) showAppSnackBar(context, 'تعذر التسجيل: $e', isError: true);
    }
  }

  Future<void> finish(bool send) async {
    try {
      final result = await AudioService.instance.stopRecording();
      if (!mounted) return;
      setState(() => recording = false);
      if (result == null) return;
      if (send) {
        final duration = DateTime.now().difference(start!);
        final conv = AppState.instance.openConversation(widget.userId);
        AppState.instance.sendVoiceMessage(conv.id, result, duration);
      } else {
        final f = File(result);
        if (await f.exists()) await f.delete();
      }
    } catch (e) {
      if (mounted) {
        setState(() => recording = false);
        showAppSnackBar(context, 'تعذر إنهاء التسجيل', isError: true);
      }
    }
  }

  @override
  void dispose() {
    if (recording) AudioService.instance.stopRecording();
    super.dispose();
  }

  @override
  Widget build(BuildContext c) {
    final app = AppState.instance;
    return Scaffold(
      appBar: AppBar(title: Text(app.userById(widget.userId).name)),
      body: AnimatedBuilder(
        animation: app,
        builder: (c, _) {
          final messages = app.conversationWith(widget.userId)?.messages ?? [];
          return Column(children: [
            Expanded(
              child: ListView(children: [
                ...messages.map((m) => Align(
                  alignment: m.senderId == app.currentUser?.id
                      ? Alignment.centerLeft : Alignment.centerRight,
                  child: Card(
                    color: m.senderId == app.currentUser?.id ? kPrimary : Colors.white,
                    child: Padding(
                      padding: const EdgeInsets.all(8),
                      child: Column(children: [
                        VoicePlayerWidget(localPath: m.localPath, duration: m.duration, color: kPrimary),
                        Text(DateFormat('HH:mm').format(m.createdAt),
                            style: const TextStyle(color: kTextMuted)),
                      ]),
                    ),
                  ),
                )),
              ]),
            ),
            SafeArea(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: recording
                    ? [
                        TextButton(onPressed: () => finish(false), child: const Text('إلغاء')),
                        ElevatedButton(onPressed: () => finish(true), child: const Text('إرسال')),
                      ]
                    : [
                        const Text('رسائل صوتية محلية'),
                        IconButton(onPressed: begin, icon: const Icon(Icons.mic, size: 38, color: kPrimary)),
                      ],
              ),
            ),
          ]);
        },
      ),
    );
  }
}
