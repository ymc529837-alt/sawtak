import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/models.dart';
class AppState extends ChangeNotifier {
 AppState._(); static final instance=AppState._();
 AppUser? currentUser; bool isPrivateAccount=false;
 final Set<String> blockedUserIds={}; final Set<String> _following={};
 final List<AppUser> users=[AppUser(id:'demo',username:'demo',name:'مستخدم صوتك',bio:'أهلاً بكم في صوتك'),AppUser(id:'sara',username:'sara',name:'سارة',bio:'أحب القصص الصوتية',avatarHue:330),AppUser(id:'omar',username:'omar',name:'عمر',bio:'صوتي حكايتي',avatarHue:160)];
 final List<VoicePost> posts=[]; final List<Conversation> conversations=[];
 Future<void> init() async { final prefs=await SharedPreferences.getInstance(); final id=prefs.getString('user_id'); if(id!=null){currentUser=users.firstWhere((u)=>u.id==id,orElse:()=>users.first);} if(posts.isEmpty){posts.addAll([VoicePost(id:'p1',userId:'sara',createdAt:DateTime.now().subtract(const Duration(hours:2)),duration:const Duration(seconds:18),caption:'صباح الخير من صوتك ☀️',likes:12),VoicePost(id:'p2',userId:'omar',createdAt:DateTime.now().subtract(const Duration(days:1)),duration:const Duration(seconds:24),caption:'وش رأيكم في التطبيق؟',likes:5)]);} notifyListeners(); }
 Future<bool> login(String email,String password) async {if(email.trim().isEmpty||password.isEmpty)return false;currentUser=users.first; final p=await SharedPreferences.getInstance();await p.setString('user_id',currentUser!.id);notifyListeners();return true;}
 Future<bool> register(String name,String email,String password) async {if(name.trim().isEmpty||email.trim().isEmpty||password.length<6)return false; final u=AppUser(id:'u${DateTime.now().millisecondsSinceEpoch}',username:email.split('@').first,name:name);users.add(u);currentUser=u;final p=await SharedPreferences.getInstance();await p.setString('user_id',u.id);notifyListeners();return true;}
 Future<void> logout() async {currentUser=null;final p=await SharedPreferences.getInstance();await p.remove('user_id');notifyListeners();}
 Future<void> deleteAccount() async {final id=currentUser?.id;if(id!=null){posts.removeWhere((p)=>p.userId==id);users.removeWhere((u)=>u.id==id);}await logout();}
 AppUser userById(String id)=>users.firstWhere((u)=>u.id==id,orElse:()=>users.first);
 List<VoicePost> postsByUser(String id)=>posts.where((p)=>p.userId==id).toList();
 bool isFollowing(String id)=>_following.contains(id); void toggleFollow(String id){_following.contains(id)?_following.remove(id):_following.add(id);notifyListeners();}
 bool isBlocked(String id)=>blockedUserIds.contains(id);void toggleBlock(String id){blockedUserIds.contains(id)?blockedUserIds.remove(id):blockedUserIds.add(id);notifyListeners();}
 void reportUser(String id,String reason){} // Demo only: no report is transmitted.
 void setPrivateAccount(bool v){isPrivateAccount=v;notifyListeners();}
 void updateProfile({required String name,required String bio,required int avatarHue}){if(currentUser==null)return;currentUser!..name=name.trim()..bio=bio..avatarHue=avatarHue;notifyListeners();}
 void addPost(String path,Duration duration,String caption){if(currentUser==null)return;posts.insert(0,VoicePost(id:'p${DateTime.now().microsecondsSinceEpoch}',userId:currentUser!.id,createdAt:DateTime.now(),duration:duration,localPath:path,caption:caption));notifyListeners();}
 void toggleLike(String id){final p=posts.firstWhere((p)=>p.id==id);p.liked=!p.liked;p.likes+=p.liked?1:-1;notifyListeners();}
 Conversation? conversationWith(String id){for(final c in conversations){if(c.otherUserId==id)return c;}return null;}
 Conversation openConversation(String id){final old=conversationWith(id);if(old!=null)return old;final c=Conversation('c${DateTime.now().microsecondsSinceEpoch}',id);conversations.add(c);notifyListeners();return c;}
 void markConversationRead(String id){}
 void sendVoiceMessage(String id,String path,Duration duration){for(final c in conversations){if(c.id==id){c.messages.add(ChatMessage(senderId:currentUser?.id??'demo',localPath:path,duration:duration,createdAt:DateTime.now()));notifyListeners();return;}}}
}
