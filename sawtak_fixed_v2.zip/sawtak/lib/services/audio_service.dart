import 'package:record/record.dart';
import 'package:path_provider/path_provider.dart';
class AudioService {
 AudioService._();static final instance=AudioService._();final AudioRecorder _recorder=AudioRecorder();
 Future<bool> ensureMicPermission()=>_recorder.hasPermission();
 Future<String> newRecordingPath() async {final dir=await getApplicationDocumentsDirectory();return '${dir.path}/sawtak_${DateTime.now().microsecondsSinceEpoch}.m4a';}
 Future<void> startRecording(String path)=>_recorder.start(const RecordConfig(encoder:AudioEncoder.aacLc),path:path);
 Future<String?> stopRecording()=>_recorder.stop();
}
