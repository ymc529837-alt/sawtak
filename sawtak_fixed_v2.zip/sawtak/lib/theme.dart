import 'package:flutter/material.dart';
const kPrimary = Color(0xFF2563EB);
const kDanger = Color(0xFFDC2626);
const kText = Color(0xFF172554);
const kTextMuted = Color(0xFF64748B);
const kBg = Color(0xFFF8FAFC);
const kBrandGradient = LinearGradient(colors: [Color(0xFF2563EB), Color(0xFF60A5FA)]);
ThemeData sawtakTheme() => ThemeData(useMaterial3: true, scaffoldBackgroundColor:kBg, colorScheme: ColorScheme.fromSeed(seedColor:kPrimary), appBarTheme: const AppBarTheme(backgroundColor:Colors.white, foregroundColor:kText), elevatedButtonTheme: ElevatedButtonThemeData(style:ElevatedButton.styleFrom(backgroundColor:kPrimary,foregroundColor:Colors.white)));
